package TestingDelivery.TestingDelivery;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DisapearingElements_9 {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://the-internet.herokuapp.com/?ref=hackernoon.com");
		WebElement ele = driver.findElement(By.xpath("//a[contains(text(),'Disappearing')]"));
		ele.click();
		
		List<WebElement> beforeRefresh = driver.findElements(By.xpath("//*[@id='content']/div/ul/li"));
		System.out.println(beforeRefresh.toString());
		Set<String> beforeString = new HashSet<String>();
		for (WebElement bs : beforeRefresh) {
			beforeString.add(bs.getText());
		}
		
		driver.navigate().refresh();
		
		List<WebElement> afterRefresh = driver.findElements(By.xpath("//*[@id='content']/div/ul/li"));
		System.out.println(afterRefresh.toString());
		Set<String> afterString = new HashSet<String>();
		for (WebElement as : afterRefresh) {
			afterString.add(as.getText());
		}
		
		if (beforeString.size() > afterString.size()) {
			
			beforeString.removeAll(afterString);
			validateString(beforeString);
		} else {
			
			afterString.removeAll(beforeString);
			validateString(afterString);
		}
	}
	
	public static void validateString(Set<String> set) {
		
		for (String s : set) {
			System.out.println(s);
		}
			
	}
}
