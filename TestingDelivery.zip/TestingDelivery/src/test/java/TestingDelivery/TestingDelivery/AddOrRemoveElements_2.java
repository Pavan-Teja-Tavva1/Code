package TestingDelivery.TestingDelivery;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddOrRemoveElements_2 {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/?ref=hackernoon.com");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		WebElement ele = driver.findElement(By.xpath("//a[normalize-space()='Add/Remove Elements']"));
		ele.click();
//		Thread.sleep(10);
		WebElement add = driver.findElement(By.xpath("//div[@class='example']/button"));
		for (int i = 0; i < 3; i++) {
			add.click();
		}
		Thread.sleep(1000);
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		WebElement del = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='elements']")));
		List<WebElement> list = driver.findElements(By.xpath("//div[@id='elements']/button"));
		System.out.println(list.size());
		for (WebElement del : list) {
			System.out.println(del);
			del.click();
		}
	}
}
