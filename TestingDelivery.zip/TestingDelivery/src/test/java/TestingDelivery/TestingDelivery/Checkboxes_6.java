package TestingDelivery.TestingDelivery;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkboxes_6 {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://the-internet.herokuapp.com/?ref=hackernoon.com");
		WebElement ele = driver.findElement(By.xpath("//a[contains(text(),'Checkboxes')]"));
		ele.click();
		
		List<WebElement> checkBoxes = driver.findElements(By.xpath("//div[@class='example']/form/input"));
		System.out.println(checkBoxes.size());
		
		for (WebElement checkBox : checkBoxes) {
			if (!checkBox.isSelected()) {
				checkBox.click();
			} else {
				checkBox.click();
			}
		}
	}
}
