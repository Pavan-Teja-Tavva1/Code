package com.booksWagon.stepDefinition;
 
 import org.openqa.selenium.WebDriver;

import com.booksWagon.pages.SearchLogin;

import io.cucumber.java.en.*;
 
 public class SearchLoginSteps {
  
  SearchLogin s = new SearchLogin();
  
  @Given("I am on the login page")
  public void I_am_on_the_login_page() {
	  s.launch();
  }
  
  @When("I enter valid credentials") 
  public void I_enter_valid_credentials() {
	  s.enterCredentials();
  }
  
  @And("I click the login button") 
  public void I_click_the_login_button() {
	  s.clickLogin();
  }
  
//  @Then("I should be redirected to the homepage") 
//  public void I_should_be_redirected_to_the_homepage() {
//  System.out.println("Inside step 4 - I am on the login page 1");
//  
//  }
//  
//  @And("The search bar should be visible") 
//  public void The_search_bar_should_be_visible() {
//  System.out.println("Inside step 5 - I am on the login page 1");
//  
//  } 
  
}
