package com.booksWagon.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.booksWagon.pages.BasePage;
import com.booksWagon.pages.SearchModule;
import com.booksWagon.utils.ExcelUtils;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BasicSearchSteps {
	
	SearchModule searchModule = new SearchModule();
	

	    String searchWord;
	    String caseType;
	    String searchResult;
	    List<String> data = new ArrayList<String>();
		
	    int row = 0;
	    public void getRow() throws IOException {
	    	row = ExcelUtils.getRowCount("TestData", "Data");
	    }
	    

	    @When("I_enter_keyword_in_search_bar_with_case_type_for_ validation")
	    public void I_enter_keyword_in_search_bar_with_case_type() throws IOException {
	       for (int i = 0; i < row; i++) {
	    	   
	    	    String searchWord = ExcelUtils.getCellData("TestData", "Data", i, 0);
	    	   	searchModule.enter_search_term(searchWord);
		    	
		    	searchModule.click_search_button();
		    	
//		    	if (caseType.equals("valid data")) {
//		            searchResult = "Java Programming Books";
//		            data.add("Pass");
//		        } else if (caseType.equals("invalid data")) {
//		            searchResult = "No results found";
//		        } else if (caseType.equals("empty data")) {
//		            searchResult = "Please enter search term";
//		        }
		    	
		    	if (searchModule.validateCase()) {
		    		data.add("Pass");
		    	} else {
		    		data.add("Fail");
		    	}
	       }
	    	   
	    	

//	        System.out.println("Entered search word: " + searchWord + " with case type: " + caseType);
	    }
	    
	    @Then ("I store the each test case after validating test case")
	    public void I_store_the_each_test_case_after_validating_test_case() throws IOException {
	    	searchModule.populateExcelData(data);
	    }
	    
	    

//	    @When("I click the search button")
//	    public void I_click_the_search_button() {
//	    	searchModule.click_search_button();
//	    	System.out.println("Search button clicked.");
//	    }
//
//	    @Then("I should see search results for basic search")
//	    public void I_should_see_search_results_related_for_basic_search() {
//	    	
//	        if (caseType.equals("valid data")) {
//	            searchResult = "Java Programming Books";
//	        } else if (caseType.equals("invalid data")) {
//	            searchResult = "No results found";
//	        } else if (caseType.equals("empty data")) {
//	            searchResult = "Please enter search term";
//	        }
//
//	        assertEquals(expectedSearchResult, searchResult);
//	        System.out.println("Expected search result: " + expectedSearchResult + " | Actual search result: " + searchResult);
//	    }
	}


