package com.booksWagon.pages;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchLogin extends BasePage {
	WebDriver driver = getDriver();
    private String baseURL;

    public SearchLogin() {
        this.baseURL = readConfig("config.txt"); // Reads the URL from the config file
    }

    private String readConfig(String configFile) {
        Properties properties = new Properties();
        try {
            properties.load(Files.newBufferedReader(Paths.get(configFile)));
            return properties.getProperty("baseURL").replace("\"", "").trim(); // Extract and clean the URL
        } catch (IOException e) {
            System.err.println("Error reading config file: " + e.getMessage());
            return null;
        }
    }

    public void launch() {
        if (baseURL != null && !baseURL.isEmpty()) {
            driver.get(baseURL); // Uses the URL from config
            driver.manage().window().maximize();
        } else {
            System.out.println("Invalid or missing URL in config file.");
        }
    }
	    
	public void enterCredentials() {
	   driver.findElement(By.xpath("//input[@placeholder='Mobile/Email']")).sendKeys("abcdef");
	   driver.findElement(By.xpath("//input[@type='password']")).sendKeys("qwerty@123");
	}
	    
	public void clickLogin() {
	   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	   wait.until(ExpectedConditions.elementToBeClickable(
	   By.xpath("//a[contains(@class, 'btn')]"))).click();
	   driver.navigate().to("https://www.bookswagon.com");
	}
	    
	public SearchModule navigateToSearch() {
	   return new SearchModule();
	}
}
