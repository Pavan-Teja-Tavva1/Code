package com.booksWagon.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.booksWagon.utils.ExcelUtils;

import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.IOException;
import java.time.Duration;
import java.util.List;


public class SearchModule extends BasePage {
    
    // Locators
	WebDriver driver = getDriver();
    private By searchBoxLocator = By.xpath("//input[@id='inputbar']");
    private By searchButtonLocator = By.xpath("//input[@id='btnTopSearch']");  

    public void enter_search_term(String searchWord) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchBox = wait.until(
            ExpectedConditions.elementToBeClickable(searchBoxLocator)
        );
        searchBox.clear();
//        if (searchWord != null && !searchWord.isEmpty()) {
//            searchBox.sendKeys(searchWord);
//        }
        searchBox.sendKeys(searchWord);
    }

    public void click_search_button() {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator))
            .click();
    }

    public boolean validateCase() {
    	List<WebElement> list = driver.findElements(By.xpath("//*[@id='listSearchResult']"));
    	if (!list.isEmpty()) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    public void populateExcelData(List<String> Data) throws IOException {
    	int row = ExcelUtils.getRowCount("TestData", "Data");
    	for (int i = 0; i < row; i++) {
    		ExcelUtils.setCellData("TestData", "Data", i, 3, Data.get(i));
    	}
    }
    
//    public String get_search_results() {
//        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
//        return wait.until(ExpectedConditions.presenceOfElementLocated(searchResultsLocator))
//                  .getText();
//    }
//
//    public boolean verify_search_results(String expectedResult) {
//        String actualResults = get_search_results();
//        
//        switch(expectedResult) {
//            case "Please enter search term":
//                return actualResults.contains("Please enter a search term") ||
//                       actualResults.contains("Search field cannot be empty");
//                       
//            case "No results found":
//                return actualResults.contains("No results found") ||
//                       actualResults.contains("No matching results");
//                       
//            default:
//                return actualResults.contains(expectedResult);
//        }
    }
    
    
