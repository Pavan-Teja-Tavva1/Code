package com.booksWagon.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


public class SearchModule extends BasePage {
    
    // Locators
    private By searchBoxLocator = By.id("inputbar");
    private By searchButtonLocator = By.xpath("//input[@value='Search']");
    private By searchResultsLocator = By.className("search-results");
    private By homePageIdentifierLocator = By.id("homepage-element");

    public boolean is_on_home_page() {
        try {
            WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
            return wait.until(ExpectedConditions.presenceOfElementLocated(homePageIdentifierLocator))
                      .isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void enter_search_term(String searchWord) {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        WebElement searchBox = wait.until(
            ExpectedConditions.elementToBeClickable(searchBoxLocator)
        );
        searchBox.clear();
        if (searchWord != null && !searchWord.isEmpty()) {
            searchBox.sendKeys(searchWord);
        }
    }

    public void click_search_button() {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator))
            .click();
    }

    public String get_search_results() {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.presenceOfElementLocated(searchResultsLocator))
                  .getText();
    }

    public boolean verify_search_results(String expectedResult) {
        String actualResults = get_search_results();
        
        switch(expectedResult) {
            case "Please enter search term":
                return actualResults.contains("Please enter a search term") ||
                       actualResults.contains("Search field cannot be empty");
                       
            case "No results found":
                return actualResults.contains("No results found") ||
                       actualResults.contains("No matching results");
                       
            default:
                return actualResults.contains(expectedResult);
        }
    }
}