package com.booksWagon.pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchLogin extends BasePage {
	WebDriver driver = getDriver();
	
	public void launch() {
	   driver.get("https://www.bookswagon.com/login");
	   driver.manage().window().maximize();
	}
	    
	public void enterCredentials() {
	   driver.findElement(By.xpath("//input[@placeholder='Mobile/Email']")).sendKeys("abcdef");
	   driver.findElement(By.xpath("//input[@type='password']")).sendKeys("qwerty@123");
	}
	    
	public void clickLogin() {
	   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	   wait.until(ExpectedConditions.elementToBeClickable(
	   By.xpath("//a[contains(@class, 'btn')]"))).click();
	}
	    
	public SearchModule navigateToSearch() {
	   return new SearchModule();
	}
	
//	public void checkHomePage() {
//		
//	}
//	
//	public void checkSearchBar() {
//		
//	}
}
