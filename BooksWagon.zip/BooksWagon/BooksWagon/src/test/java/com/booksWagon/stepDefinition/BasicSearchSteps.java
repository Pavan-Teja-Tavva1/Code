package com.booksWagon.stepDefinition;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.booksWagon.pages.BasePage;
import com.booksWagon.pages.SearchModule;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BasicSearchSteps {
	
	SearchModule searchModule = new SearchModule();
	
	
    @Given("I am logged in and on the homepage")
    public void I_am_logged_in_and_on_the_page() {
   
        Assert.assertTrue(searchModule.isOnHomePage(), "User is not on homepage");
    }

    @When("I enter {string} in search bar with {string} type")
    public void I_enter_string_in_search_bar_with_string_type(String searchWord, String description) {
        searchModule.enterSearchTerm(searchWord);
    }

    @And("I click the search button")
    public void I_click_the_search_button() {
        searchModule.clickSearchButton();
    }

    @Then("I should see search results related to {string}")
    public void I_should_see_Search_results_related_to_string(String expectedResult) {
        String actualResult = searchModule.getSearchResults();
        Assert.assertTrue(
            searchModule.verifySearchResults(expectedResult),
            "Expected result '" + expectedResult + "' not found in actual results: '" + actualResult + "'"
        );
    }
}
