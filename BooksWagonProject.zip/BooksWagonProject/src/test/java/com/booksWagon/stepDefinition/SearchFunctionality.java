package com.booksWagon.stepDefinition;

import java.io.IOException;
import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.booksWagon.pages.SearchPage;
import com.booksWagon.utils.Utils;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchFunctionality {
	
	WebDriver driver = new ChromeDriver();
	SearchPage search = new SearchPage();
	String path = "C:\\Users\\tavva.teja\\Downloads\\BooksWagonProject\\BooksWagonProject\\src\\test\\resources\\testingData\\TestData.xlsx";
	List<String> list = new ArrayList<String>();
	
	@Given("user is logged in and is on homepage")
	public void user_is_logged_in_and_is_on_homepage() throws IOException {
		search.launch();
		search.enterCredentials();
	}
	
	@When("user is searching for item and searched items are shown")
	public void user_is_searching_for_item_and_searched_items_are_shown() throws IOException {
		
		  int row = Utils.getRowCount(path, "Data1");

		  for (int i = 1; i < row; i++) {

			  String keywordToSearch = Utils.getCellData(path, "Data1", i, 0);
			  System.out.println(keywordToSearch);
			  search.enterAndSearch(keywordToSearch);
			  Boolean val = search.validateSearch(keywordToSearch);
			  System.out.println(val);
			  search.navigateBack();
		  }
//		  String keywordToSearch = Utils.getCellData(path, "Data1", 1, 0);
//		  System.out.println(keywordToSearch);
//		  search.enterAndSearch(keywordToSearch);
//		
//		search.enterAndSearch("selenium");
	     for (int i = 0; i < list.size(); i++) {
	    	 System.out.println(list.get(i));
	     }
	}
	
    @Then ("storing the result in excel")
    public void storing_the_result_in_excel() throws IOException {
		int row = Utils.getRowCount(path, "Data1");

    	search.populateExcel(path, list, row);
    }
    
    @When ("user is searching for item and searched refined items are shown")
    public void user_is_searching_for_item_and_searched_refined_items_are_shown() throws IOException {
    	String keywordToSearch = Utils.getCellData(path, "Data2", 1, 0);
		  System.out.println(keywordToSearch);
		  search.enterAndSearch(keywordToSearch);
    }



	@And ("user is refining the search by title")
	public void user_is_refining_the_search_by_title() throws InterruptedException, IOException {
    	search.searchTitle();
    	boolean val = search.assertTitle();
    	System.out.println("ass : "+ val);
    	search.navigateBack();
    	Utils.setCellData(path, "Data2", 1, 3, Boolean.toString(val));

	}
	
//	todo debug
//	@And ("user is refining the search by price")
//	public void user_is_refining_the_search_by_price() {
////    	search.searchPrice();
////    	search.assertPrice();
//		System.out.println("Hi");
//
//	}
	
//	todo
//	@And ("user is refining the search by discount")
//	public void user_is_refining_the_search_by_discount() {
////    	search.searchDiscount();
////    	search.assertDiscount();
//		System.out.println("Hi");
//
//	}
	
	@And ("user is refining the search by availability")
	public void user_is_refining_the_search_by_availability() throws InterruptedException, IOException {
    	search.searchAvailability();
    	boolean val = search.assertAvailability();
    	System.out.println("val : "+ val);
    	search.navigateBack();
    	Utils.setCellData(path, "Data2", 2, 3, Boolean.toString(val));

	}
//	todo
	@And ("user is refining the search by binding")
	public void user_is_refining_the_search_by_binding() throws InterruptedException, IOException {		
		search.searchBinding();
		boolean val = search.assertBinding();
		System.out.println("val : "+ val);
		search.navigateBack();
    	Utils.setCellData(path, "Data2", 3, 3, Boolean.toString(val));

		
	}

//	@And ("user is refining the search by shipping time")
//	public void user_is_refining_the_search_by_shipping_time() throws InterruptedException {
//    	search.searchShippingTime();
//		search.assertShippingTime();
//    }
//    
//    @And ("user is refining the search by source")
//	public void user_is_refining_the_search_by_source() {
//    	System.out.println("Hi");
//
//    }
//    
//    
    @And ("user is refining the search by language")
	public void user_is_refining_the_search_by_language() throws InterruptedException, IOException {
    	search.searchLanguage();
    	boolean val = search.assertLangauge();
    	System.out.println("val : "+ val);
    	search.navigateBack();
    	Utils.setCellData(path, "Data2", 4, 3, Boolean.toString(val));


    }
//    todo
//    @And ("user is refining the search by publication year")
//    public void user_is_refining_the_search_by_publication_year() {
//    	System.out.println("Hi");
//
//    }
//
   



}
