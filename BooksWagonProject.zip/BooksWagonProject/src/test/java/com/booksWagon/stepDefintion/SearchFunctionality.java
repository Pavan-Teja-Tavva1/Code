//package com.booksWagon.stepDefintion;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import com.booksWagon.pages.SearchPage;
//
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class SearchFunctionality {
//	
//	WebDriver driver = new ChromeDriver();
//	SearchPage search = new SearchPage(driver);
//	
//	@Given ("user is logged in and is on homepage")
//	public void user_is_logged_in_and_is_on_homepage() {
//		search.launch();
//		search.enterCredentials();
//	}
//	
//	
//    @When ("user is searching for item")
//	public void user_is_searching_for_item() {
//    	
//    }
//    
//    @Then ("Items are shown as per searched data")
//    public void Items_are_shown_as_per_searched_data() {
//    	System.out.println("Hi");
//
//    }
//	
//	@And ("user is refining the search by title")
//	public void user_is_refining_the_search_by_title() {
//    	search.searchTitle();
//    	search.assertTitle();
//
//	}
//	
//	@And ("user is refining the search by price")
//	public void user_is_refining_the_search_by_price() {
//    	search.searchPrice();
//    	search.assertPrice();
//
//	}
//	
//	@And ("user is refining the search by discount")
//	public void user_is_refining_the_search_by_discount() {
//    	search.searchDiscount();
//    	search.assertDiscount();
//
//	}
//	
//	@And ("user is refining the search by availability")
//	public void user_is_refining_the_search_by_availability() {
//    	search.searchAvailability();
//    	search.assertAvailability();
//
//	}
//	
//    @And ("user is refining the search by shipping time")
//	public void user_is_refining_the_search_by_shipping_time() {
//    	search.searchShippingTime();
//    	search.assertShippingTime();
//
//    }
//    
//    @And ("user is refining the search by source")
//	public void user_is_refining_the_search_by_source() {
//    	System.out.println("Hi");
//
//    }
//    
//    @And ("user is refining the search by binding")
//	public void user_is_refining_the_search_by_binding() {
//    	System.out.println("Hi");
//
//    }
//    
//    @And ("user is refining the search by language")
//	public void user_is_refining_the_search_by_language() {
//    	System.out.println("Hi");
//
//    }
//    
//    @And ("user is refining the search by publication year")
//    public void user_is_refining_the_search_by_publication_year() {
//    	System.out.println("Hi");
//
//    }
//
//
//
//
//}
