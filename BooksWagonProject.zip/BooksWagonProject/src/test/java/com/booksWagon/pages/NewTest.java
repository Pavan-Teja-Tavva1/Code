package com.booksWagon.pages;

import org.testng.annotations.Test;

public class NewTest {
	SearchPage search = new SearchPage();
  @Test
  public void f() {
	  search.launch();
	  search.enterCredentials();
	  search.enterAndSearch();
	  search.searchAvailability();
//	  search.searchBinding();
	  search.searchDiscount();
//	  search.searchLanguage();
	  search.searchPrice();
	  search.searchPublicationYear();
	  search.searchShippingTime();
	  search.searchSource();
	  search.searchTitle();
  }
}
