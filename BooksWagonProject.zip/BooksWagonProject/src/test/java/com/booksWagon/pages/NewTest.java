package com.booksWagon.pages;

import org.testng.annotations.Test;

public class NewTest {
	SearchPage search = new SearchPage();
  @Test
  public void f() throws InterruptedException {
	  search.launch();
//	  search.enterCredentials();
	  search.enterAndSearch();
	  search.searchAvailability();
//	  search.searchBinding();
//	  search.searchDiscount();
//	  search.searchLanguage();
//	  search.searchPrice();
//	  boolean val = search.assertPrice();
//	  search.searchPublicationYear();
//	  search.searchShippingTime();
//	  search.searchSource();
//	  search.searchTitle();
//	  boolean val = search.assertTitle();
	  
//	  System.out.println(val);
  }
}
