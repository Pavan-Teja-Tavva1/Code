package com.booksWagon.testNG;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.booksWagon.pages.SearchPage;
import com.booksWagon.utils.Utils;

public class NewTest {
	SearchPage search = new SearchPage();
  @Test
  public void f() throws InterruptedException, IOException {
//	  List<String> list = new ArrayList<>();
//	  search.launch();
//	  search.enterCredentials();
//	  String path = "C:\\Users\\tavva.teja\\Downloads\\BooksWagonProject\\BooksWagonProject\\src\\test\\resources\\testingData\\TestData.xlsx";
//
//	  int row = Utils.getRowCount(path, "Data1");
//	  for (int i = 1; i < row; i++) {
//		  String word = Utils.getCellData(path, "Data1", i, 0);
//		  search.enterAndSearch(word);
//		  Boolean val = search.validateSearch(word);
//		  System.out.println(val);
//		  list.add(val.toString());
//		  System.out.println(list.toString());
//		  search.navigateBack();
//	  }
//	  search.populateExcel(path, list, row);
//	  search.searchAvailability();
//	  Boolean val = search.assertAvailability();
//	  search.searchBinding();
//	  Boolean val = search.assertBinding();
//	  search.searchDiscount();
//	  search.searchLanguage();
//	  Boolean val = search.assertLangauge();
//	  search.searchPrice();
//	  boolean val = search.assertPrice();
//	  search.searchPublicationYear();
//	  boolean val = search.assertPublicationYear();
//	  search.searchShippingTime();
//	  search.assertShippingTime();
//	  search.searchSource();
//	  search.searchTitle();
//	  boolean val = search.assertTitle();
	  
//	  System.out.println(val);
	  
	  
  }
}
