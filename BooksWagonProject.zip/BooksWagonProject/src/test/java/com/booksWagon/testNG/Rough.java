package com.booksWagon.testNG;

import java.io.IOException;

import com.booksWagon.utils.Utils;

public class Rough {

	public static void main(String[] args) throws IOException {
		  int row = Utils.getRowCount("C:\\Users\\tavva.teja\\Downloads\\BooksWagonProject\\BooksWagonProject\\src\\test\\resources\\testingData\\TestData.xlsx", "Data1");
		  for (int i = 1; i < row; i++) {
			  String word = Utils.getCellData("C:\\Users\\tavva.teja\\Downloads\\BooksWagonProject\\BooksWagonProject\\src\\test\\resources\\testingData\\TestData.xlsx", "Data1", i, 0);
			  System.out.println(word);
		  }
		  	
	}

}
