package com.booksWagon.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchPage {
	WebDriver driver;
	
	public SearchPage() {
		this.driver = new ChromeDriver();
	}
	
	public void launch() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.bookswagon.com/login");
		driver.manage().window().maximize();
	}
	
	public void enterCredentials() {
		WebElement mob = driver.findElement(By.xpath("//input[@id='ctl00_phBody_SignIn_txtEmail']"));
		mob.sendKeys("7004481495");
		
		WebElement passWord = driver.findElement(By.xpath("//input[@id='ctl00_phBody_SignIn_txtPassword']"));
		passWord.sendKeys("abcdef");
		
		WebElement login = driver.findElement(By.xpath("//a[@id='ctl00_phBody_SignIn_btnLogin']"));
		login.click();
		
		driver.navigate().to("https://www.bookswagon.com");
	}
	
	 public void enterAndSearch() {
		 WebElement searchBar = driver.findElement(By.xpath("//input[@id='inputbar']"));
		 searchBar.sendKeys("Selenium");
		 WebElement searchButton = driver.findElement(By.xpath("//input[@id='btnTopSearch']"));
		 searchButton.click();
	 }
	 
	 public void searchTitle() {
		 
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 WebElement discountElement = wait.until(ExpectedConditions.elementToBeClickable(
				 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[2]/a"))
		 );
		 discountElement.click();
	 }
	 
//	 public void assertTitle() {
//		 
//	 }
	 
	 public void searchPrice() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 WebElement price = wait.until(ExpectedConditions.elementToBeClickable(
				 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[2]/li[2]/a")
		 ));
		 price.click();
	 }
	 
//	 public void assertPrice() {
//		 
//	 }
	 
	 public void searchDiscount() {
		 
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 WebElement discountElement = wait.until(ExpectedConditions.elementToBeClickable(
		 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[3]/li[2]/a")
		 ));
		 discountElement.click();
		 

	 }
	 
//	 public void assertDiscount() {
//	
//	 }
	 
	 public void searchAvailability() {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 WebElement avail = wait.until(ExpectedConditions.elementToBeClickable(
				 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[4]/li[3]/a")
		 ));
		 avail.click();
	 }
	 
//	 public void assertAvailability() {
//		 
//	 }
	 
	 public void searchShippingTime() {
		 
		  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  WebElement ship = wait.until(ExpectedConditions.elementToBeClickable(
		       By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[5]/li[2]/a")
		     ));
		  ship.click();
		 

	 }
	 
//	 public void assertShippingTime() {
//		 
//	 }
	 
	 public void searchSource() {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  WebElement source = wait.until(ExpectedConditions.elementToBeClickable(
				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[6]/li[2]/a")
		     ));
		  source.click();
	 }
	 
//	 public void assertSource() {
//		 
//	 }
	 
	 public void searchBinding() {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  WebElement bind = wait.until(ExpectedConditions.elementToBeClickable(
				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[7]/li[2]/a"))
		     );
		  bind.click();
	 }
	 
//	 public void assertBinding() {
//		 
//	 }
	 
	 public void searchLanguage() {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  WebElement language = wait.until(ExpectedConditions.elementToBeClickable(
				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[8]/li[2]/a"))
		     );
		  language.click();
		 
	 }
	 
//	 public void assertLangauge() {
//		 
//	 }
	 
	 public void searchPublicationYear() {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  WebElement year = wait.until(ExpectedConditions.elementToBeClickable(
				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[9]/li[2]/a"))
		     );
		  year.click();
	 }
	 
	 
}
