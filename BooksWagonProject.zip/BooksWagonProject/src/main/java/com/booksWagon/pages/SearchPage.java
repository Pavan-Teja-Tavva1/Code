package com.booksWagon.pages;

import java.util.ArrayList;
import java.util.List;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchPage {
	WebDriver driver;
	
	public SearchPage() {
		this.driver = new ChromeDriver();
	}
	
	public void launch() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.bookswagon.com");
		driver.manage().window().maximize();
	}
	
	public void enterCredentials() {
		WebElement mob = driver.findElement(By.xpath("//input[@id='ctl00_phBody_SignIn_txtEmail']"));
		mob.sendKeys("7004481495");
		
		WebElement passWord = driver.findElement(By.xpath("//input[@id='ctl00_phBody_SignIn_txtPassword']"));
		passWord.sendKeys("abcdef");
		
		WebElement login = driver.findElement(By.xpath("//a[@id='ctl00_phBody_SignIn_btnLogin']"));
		login.click();
		
		driver.navigate().to("https://www.bookswagon.com");
	}
	
	 public void enterAndSearch() {
		 driver.get("https://www.bookswagon.com");
		 WebElement searchBar = driver.findElement(By.xpath("//input[@id='inputbar']"));
		 searchBar.sendKeys("Selenium");
		 WebElement searchButton = driver.findElement(By.xpath("//input[@id='btnTopSearch']"));
		 searchButton.click();
	 }
	 
	 
	 
	 public void enter_and_search_keyword(String keyword) {
		 
		 	By searchBar = By.xpath("//input[@id='inputbar']");
		 	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        WebElement bar = wait.until(ExpectedConditions.elementToBeClickable(searchBar));
	        bar.clear(); 
	        
	        if (keyword != null) {
	            bar.sendKeys(keyword);
	        }
	        
	        By searchButton = By.xpath("//input[@id='btnTopSearch']");
	        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
	        WebElement button = wait1.until(ExpectedConditions.elementToBeClickable(searchButton));
	        button.click();
	        
	 }
	 
	 public void validateCase() {
		 
	 }
	 
//	 
	 
	 public void searchTitle() throws InterruptedException {
		 
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		 WebElement discountElement = wait.until(ExpectedConditions.elementToBeClickable(
//				 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[2]/a"))
//		 );
		 driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[2]/a")).click();
		 Thread.sleep(100);
	 }
	 
	 public boolean assertTitle() {
		 
		 List<WebElement> title = driver.findElements(By.xpath("//div[@class='title']")); 
		 List<String> list = new ArrayList<>();
		 
		 for (WebElement bookTitle : title) {
			 list.add(bookTitle.getText());
		 }
		 
		 for (int i = 0; i < list.size(); i++) {
			 System.out.println(list.get(i));
		 }
		 
		 for (int i = 1; i < list.size(); i++) {
			 if(!list.get(i).contains("Selenium") || list.get(i).contains("selenium")) {
				 return false;
			 }
		 }
		 
		 return true;
		 
		 
		 
	 }
	
	 
	 public void searchPrice() throws InterruptedException {
//		Thread.sleep(10);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 WebElement price = wait.until(ExpectedConditions.elementToBeClickable(
				 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[2]/li[2]/a")
		 ));
		 price.click();
		 
//		driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[2]/li[2]/a")).click();

		 
	 }
	 
	 public boolean assertPrice() {
		 List<WebElement> price = driver.findElements(By.xpath("//div[@class='price']/div[@class='sell']")); 
		 List<String> list = new ArrayList<>();
		 
		 for (WebElement bookPrice : price) {
			 list.add(bookPrice.getText());
		 }
		 
		 for (int i = 0; i < list.size(); i++) {
			 System.out.println(list.get(i));
		 }
		 
		 int num = 0;
		 for (int i = 0; i < list.size(); i++) {
			 num = Integer.parseInt(list.get(i));
			 if(!(num >= 100 && num <= 500)) {
				 return false;
			 }
		 }
		 
		 return true;
	 }
	 
	 public void searchDiscount() throws InterruptedException {
		 
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		 WebElement discountElement = wait.until(ExpectedConditions.elementToBeClickable(
//		 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[3]/li[2]/a")
//		 ));
		 driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[3]/li[2]/a")).click();
		 
		 

	 }
	 
//	 public void assertDiscount() {
//	
//	 }
	 
	 public void searchAvailability() throws InterruptedException {
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		 WebElement avail = wait.until(ExpectedConditions.elementToBeClickable(
//				 By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[4]/li[3]/a")
//		 ));
		 driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[4]/li[3]/a")).click();
	 }
	 
	 public void assertAvailability() {
		 List<WebElement> avail = driver.findElements(By.xpath("//div[@class='out-of-stock']"));
		 List<String> list = new ArrayList<>();
		 
		 for (int i = 0; i < avail.size(); i++) {
			 list.add(avail.get(i).getText());
		 }
		 
		 for (int i = 0; i < list.size(); i++) {
			 
		 }
	 }
	 
	 public void searchShippingTime() throws InterruptedException {
		  Thread.sleep(10);
//		  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		  WebElement ship = wait.until(ExpectedConditions.elementToBeClickable(
//		       By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[5]/li[2]/a")
//		     ));
		  driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[1]/div[2]/div[1]/ul[5]/li[2]/a")).click();
		 

	 }
	 
//	 public void assertShippingTime() {
//		 
//	 }
	 
	 public void searchSource() throws InterruptedException {
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		  WebElement source = wait.until(ExpectedConditions.elementToBeClickable(
//				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[6]/li[2]/a")
//		     ));
		  driver.findElement(By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[6]/li[2]/a")).click();
	 }
	 
//	 public void assertSource() {
//		 
//	 }
	 
	 public void searchBinding() throws InterruptedException {
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		  WebElement bind = wait.until(ExpectedConditions.elementToBeClickable(
//				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[7]/li[2]/a"))
//		     );
		  driver.findElement(By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[7]/li[2]/a")).click();
	 }
	 
	 public void assertBinding() {
		 WebElement bind = driver.findElement(By.xpath("//*[@id='listSearchResult']"));
		 
	 }
	 
	 public void searchLanguage() throws InterruptedException {
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		  WebElement language = wait.until(ExpectedConditions.elementToBeClickable(
//				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[8]/li[2]/a"))
//		     );
		  driver.findElement(By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[8]/li[2]/a")).click();
		 
	 }
	 
//	 public void assertLangauge() {
//		 
//	 }
	 
	 public void searchPublicationYear() throws InterruptedException {
		 Thread.sleep(10);
//		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		  WebElement year = wait.until(ExpectedConditions.elementToBeClickable(
//				  By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[9]/li[2]/a"))
//		     );
		  driver.findElement(By.xpath("//*[@id='site-wrapper']/div[1]/div[1]/div[2]/div[1]/ul[9]/li[2]/a")).click();
	 }
	 
	 
}
