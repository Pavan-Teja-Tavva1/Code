package com.booksWagon.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.booksWagon.pages.BasePage;
import com.booksWagon.pages.SearchModule;
import com.booksWagon.utils.ExcelUtils;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BasicSearchSteps {
	
		WebDriver driver = BasePage.getDriver(); // assuming you have a static getDriver() method
		SearchModule searchModule = new SearchModule(driver);

	

	    String searchWord;
	    String caseType;
	    String searchResult;
	    List<String> data = new ArrayList<String>();
		
	    int row = 0;
	    public void getRow() throws IOException {
	    	row = ExcelUtils.getRowCount("TestData.xlsx", "Data");
	    }
	    
	    @When("I enter keyword in search bar with case type for validation")
	    public void i_enter_keyword_in_search_bar_with_case_type_for_validation() throws IOException {
	    	for (int i = 0; i < row; i++) {
		    	   
	    	    String searchWord = ExcelUtils.getCellData("TestData.xlsx", "Data", i, 0);
	    	   	searchModule.enter_search_term(searchWord);
		    	
		    	searchModule.click_search_button();
		    	
		    	searchModule.validateCase();
	       }
	    }
	    
	    @Then ("I store the each test case after validating test case")
	    public void I_store_the_each_test_case_after_validating_test_case() throws IOException {
	    	searchModule.populateExcelData(data, "Data1");
	    }
}


