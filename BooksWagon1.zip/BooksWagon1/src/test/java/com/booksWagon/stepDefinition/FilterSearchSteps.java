package com.booksWagon.stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.booksWagon.pages.BasePage;
import com.booksWagon.pages.SearchModule;
import com.booksWagon.utils.ExcelUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FilterSearchSteps extends BasePage {
	
	WebDriver driver = BasePage.getDriver(); 
	SearchModule search = new SearchModule(driver);

	
	WebElement ele = null;
	
	List<String> data = new ArrayList<String>();
	
	int row = 0;
    public void getRow() throws IOException {
    	row = ExcelUtils.getRowCount("src/test/resources/testingData/TestData.xlsx", "Data");
    }
	
	@When ("I enter keyword in the search bar for validation")
	public void I_enter_keyword_in_the_search_bar_for_validation() throws IOException {
		search.enter_search_term("Selenium");
		search.click_search_button();
		Actions actions = new Actions(driver);

		for (int i = 0; i < row; i++) {
			String path = ExcelUtils.getCellData("TestData", "Data2", i, 0);
			By xp = By.xpath(path);
			ele = driver.findElement(xp); 
			actions.moveToElement(ele).click().build().perform();
			
			if (search.validateCaseFilter(ele)) {
				data.add("Pass");
			} else {
				data.add("Fail");
			}
		}
	}
	
    @And ("I store the each test case after validating test case for refined search")
    public void I_store_the_each_test_case_after_validating_test_case_for_refined_search() throws IOException {
    	search.populateExcelData(data, "Data2");
    }
    
}