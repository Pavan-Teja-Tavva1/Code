package com.booksWagon.hooks;

import com.booksWagon.pages.BasePage;
import io.cucumber.java.After;
import io.cucumber.java.Before;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hooks {
    
    @Before
    public void setUp() {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        
        BasePage.setDriver(driver);
    }
    
    @After
    public void tearDown() {
        WebDriver driver = BasePage.getDriver();
        if (driver != null) {
            driver.quit();
        }
    }
}
