package com.booksWagon.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.booksWagon.utils.ExcelUtils;

import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class SearchModule extends BasePage {
    
	

	public SearchModule(WebDriver driver) {
	    this.driver = driver;
	}
	

    // Locators
	WebDriver driver = getDriver();
    private By searchBoxLocator = By.xpath("//input[@id='inputbar']");
    private By searchButtonLocator = By.xpath("//a[contains(@id, 'ctl00')]");  

    public void enter_search_term(String searchWord) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchBox = wait.until(
            ExpectedConditions.elementToBeClickable(searchBoxLocator)
        );
        searchBox.clear();
       
        searchBox.sendKeys(searchWord);
    }

    public void click_search_button() {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator))
            .click();
    }

    public boolean validateCase() {
    	List<WebElement> list = driver.findElements(By.xpath("//div/div/a[contains(text(),'Java')]"));
    	
    	for (WebElement ele : list) {
    		String text = ele.getText();
    		if (!text.contains("Java")) {
    			return false;
    		}
    	}
    	return true;
    }
    
    public boolean validateCaseFilter(WebElement Element) {
    	
    	WebElement ele = Element;
    	String fullText1 = ele.getText(); 
    	String num1 = fullText1.replaceAll("[^0-9]", ""); 
    	

    	WebElement validate = driver.findElement(By.xpath("//div[@class='preferences-show']/b"));
    	String fullText2 = validate.getText();
    	String num2 = fullText2.replaceAll("[^0-9]", ""); 
    	
    	return num1.equals(num2);
    }
    
    public void populateExcelData(List<String> Data, String xlsheet) throws IOException {
    	int row = ExcelUtils.getRowCount("TestData", xlsheet);
    	for (int i = 0; i < row; i++) {
    		ExcelUtils.setCellData("TestData", "Data", i, 3, Data.get(i));
    	}
    }
    
}
    
    
