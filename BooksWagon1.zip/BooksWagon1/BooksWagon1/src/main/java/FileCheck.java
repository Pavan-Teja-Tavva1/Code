
	import java.io.File;
import java.io.IOException;

import com.booksWagon.utils.ExcelUtils;

	public class FileCheck {
	    public static void main(String[] args) throws IOException {
	    	String path = "C:\\Users\\tavva.teja\\Downloads\\BooksWagon1\\BooksWagon1\\src\\test\\resources\\testingData\\TestData.xlsx";
		    int row = ExcelUtils.getRowCount(path, "Data1");
		    System.out.println(row);
		    
	    }
	}


