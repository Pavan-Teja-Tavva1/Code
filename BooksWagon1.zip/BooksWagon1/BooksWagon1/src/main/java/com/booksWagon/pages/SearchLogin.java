//package com.booksWagon.pages;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.time.Duration;
//import java.util.Properties;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//public class SearchLogin extends BasePage {
//
//    public void launch() {
//    	WebDriver driver = getDriver();
//        System.out.println("Initializing the browser");
//        driver.get("https://www.bookswagon.com/login"); // Uses the URL from config
//        driver.manage().window().maximize();
//       
//    }
//	    
//	public void enterCredentials() {
//	   getDriver().findElement(By.xpath("//input[@placeholder='Mobile/Email']")).sendKeys("abcdef");
//	   getDriver().findElement(By.xpath("//input[@type='password']")).sendKeys("qwerty@123");
//	}
//	    
//	public void clickLogin() {
////	   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
////	   wait.until(ExpectedConditions.elementToBeClickable(
////	   getDriver().findElement(By.xpath("//a[contains(@class, 'btn')]")))).click();
////	   getDriver().navigate().to("https://www.bookswagon.com");
//	   
////	   WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
////	   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(@class, 'btn')]")));
////	   wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class, 'btn')]"))).click();
////	   getDriver().navigate().to("https://www.bookswagon.com");
//	   
//	   getDriver().findElement(By.xpath("//*[@id='ctl00_phBody_SignIn_btnLogin']")).click();
//	   getDriver().navigate().to("https://www.bookswagon.com");
//	}
//	    
//	public SearchModule navigateToSearch() {
//	   return new SearchModule(driver);
//	}
//}
