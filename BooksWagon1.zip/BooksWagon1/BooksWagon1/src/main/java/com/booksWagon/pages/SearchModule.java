//package com.booksWagon.pages;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import com.booksWagon.utils.ExcelUtils;
//
//import org.openqa.selenium.support.ui.ExpectedConditions;
//
//import java.io.IOException;
//import java.time.Duration;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//
//public class SearchModule  {
//    
//	 private WebDriver driver;
//
//	 public SearchModule(WebDriver driver) {
//	       this.driver = driver;
//	       driver.get("https://www.bookswagon.com");
//	       driver.manage().window().maximize();
//	 }
//	
//    // Locators
////	WebDriver driver = getDriver();
//    private By searchBoxLocator = By.xpath("//input[@id='inputbar']");
//    private By searchButtonLocator = By.xpath("//*[@id='btnTopSearch']");  
//
//    public void enter_search_term(String searchWord) {
////        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
////        WebElement searchBox = wait.until(
////            ExpectedConditions.elementToBeClickable(searchBoxLocator)
////        );
//    	WebElement searchBox = driver.findElement(searchBoxLocator);
//        searchBox.clear();
//       
//        searchBox.sendKeys(searchWord);
//    }
//
//    public void click_search_button() {
////        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
////        wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator))
////            .click();
////    	WebElement searchButton = driver.findElement(searchBoxLocator);
////    	searchButton.click();
//    	 
//    	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//    	    WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator));
//    	    searchButton.click();
//    	
//
//    }
//
//    public boolean validateCase(String keyword) {
//    	List<WebElement> elements = driver.findElements(By.xpath("//div/div/a[contains(text(),'" + keyword + "')]"));    	
//    	for (WebElement ele : elements) {
//    		String text = ele.getText();
//    		if (!text.contains(keyword)) {
//    			return false;
//    		}
//    	}
//    	return true;
//    }
//    
//    public boolean validateCaseFilter(WebElement Element) {
//    	
//    	WebElement ele = Element;
//    	String fullText1 = ele.getText(); 
//    	String num1 = fullText1.replaceAll("[^0-9]", ""); 
//    	
//
//    	WebElement validate = driver.findElement(By.xpath("//div[@class='preferences-show']/b"));
//    	String fullText2 = validate.getText();
//    	String num2 = fullText2.replaceAll("[^0-9]", ""); 
//    	
//    	return num1.equals(num2);
//    }
//    
//    public void populateExcelData(List<String> Data, String xlsheet) throws IOException {
//    	int row = ExcelUtils.getRowCount("src/test/resources/testingData/TestData.xlsx", xlsheet);
//    	for (int i = 0; i < row; i++) {
//    		ExcelUtils.setCellData("src/test/resources/testingData/TestData.xlsx", "Data", i, 3, Data.get(i));
//    	}
//    }
//    
//}
//    

package com.booksWagon.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.booksWagon.utils.ExcelUtils;

import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.IOException;
import java.time.Duration;
import java.util.*;

public class SearchModule {

    private WebDriver driver;

    public SearchModule(WebDriver driver) {
        this.driver = driver;
        driver.get("https://www.bookswagon.com");
        driver.manage().window().maximize();
    }

    // Locators
    private By searchBoxLocator = By.xpath("//input[@id='inputbar']");
    private By searchButtonLocator = By.xpath("//*[@id='btnTopSearch']");
//    private By searchResultsLocator = By.xpath("//div/div/a[contains(text(),'Java')]");

    public void enter_search_term(String searchWord) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(searchBoxLocator));
        searchBox.clear(); // Ensure search bar is reset

        // Instead of skipping blank values, enter nothing into the search bar
        if (searchWord != null) {
            searchBox.sendKeys(searchWord);
        }
        
    }

    public void click_search_button() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator));
        searchButton.click();
    }

//    1)
//    public boolean validateCase(String keyword, List<String> resultList) {
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body")));
//
//        System.out.println("Validating search results for: " + (keyword.isEmpty() ? "[BLANK]" : keyword));
//
//        // Handle blank searches explicitly
//        if (keyword == null || keyword.trim().isEmpty()) {
//            List<WebElement> noResultsMessage = driver.findElements(By.xpath("//div[contains(text(),'No results found')]"));
//            if (!noResultsMessage.isEmpty()) {
//                System.out.println("No results found for blank search.");
//                resultList.add("Blank Search: False");
//                return false;
//            } else {
//                System.out.println("Blank search returned results.");
//                resultList.add("Blank Search: True");
//                return true;
//            }
//        }
//
//        // Handle valid and invalid keyword searches
//        List<WebElement> elements = driver.findElements(By.xpath("//div/div/a[contains(text(),'" + keyword + "')]"));
//
//        System.out.println("Number of results found: " + elements.size());
//
//        if (elements.isEmpty()) {
//            System.out.println("No results found for keyword: " + keyword);
//            resultList.add("False");
//            return false;
//        }
//
//        System.out.println("Found " + elements.size() + " results for keyword: " + keyword);
//        resultList.add("True");
//        return true;
//    }

    public boolean validateCase(String keyword, List<String> resultList) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body")));
        List<WebElement> elements = new ArrayList<WebElement>();
        System.out.println("Validating search results for: " + (keyword == null || keyword.trim().isEmpty() ? "[BLANK]" : keyword));
        System.out.println(driver.getCurrentUrl());

List<WebElement> elements2 = driver.findElements(By.xpath("//*[@id=\"site-wrapper\"]"));
int count = elements2.size();
System.out.println("Number of elements: " + count);

        System.out.println(driver);
        String url = driver.getCurrentUrl();
        if (url.equals("https://www.bookswagon.com/" + keyword)) {

            elements = driver.findElements(By.xpath("//div/div/a[contains(text(),'" + keyword + "')]"));

        }
        

        // Case 1: **Blank Search (Pass if no results)**
        if (keyword == null || keyword.trim().isEmpty()) {
            boolean result = elements.isEmpty(); // Pass if no results found
            System.out.println(result);
            System.out.println(elements.size());
            for (int i = 0; i < 3; i++) {
            	System.out.println(elements.get(i));
            }
            resultList.add(elements.size() > 0 ? "Fail" : "Pass");
            System.out.println(result ? "✅ Blank search: Pass" : "❌ Blank search returned results: Fail");
            return result;
        }

        // Case 2: **Valid Keyword (Pass if results found)**
        if (keyword.equalsIgnoreCase(keyword)) {  // Validate only for Java
            boolean result = !elements.isEmpty(); // Pass if results exist
            System.out.println(result);
            System.out.println(elements.size());
            resultList.add(elements.size() > 0 ? "Pass" : "Fail");
            System.out.println(result ? "✅ Valid search: Pass" : "❌ Valid search found no results: Fail");
            return result;
        }

        // Case 3: **Invalid Keyword (Pass if NO results found)**
        boolean result = elements.isEmpty(); // Pass if no results exist
        System.out.println(result);
        System.out.println(elements.size());
        resultList.add(elements.size() == 0 ? "Pass" : "Fail");
        System.out.println(result ? "✅ Invalid search: Pass" : "❌ Invalid search returned results: Fail");
        return result;
    }



    public void populateExcelData(List<String> Data, String xlsheet) throws IOException {
        int row = ExcelUtils.getRowCount("src/test/resources/testingData/TestData.xlsx", xlsheet);
        for (int i = 0; i < row; i++) {
            ExcelUtils.setCellData("src/test/resources/testingData/TestData.xlsx", "Data", i, 3, Data.get(i));
        }
    }
}

    
