//package com.booksWagon.stepDefinition;
// 
// import org.openqa.selenium.WebDriver;
//
//import com.booksWagon.pages.SearchLogin;
//
//import io.cucumber.java.en.*;
// 
// public class SearchLoginSteps {
//  
//  SearchLogin s = new SearchLogin();
//  
//  @Given("I am on the login page")
//  public void I_am_on_the_login_page() {
//	  s.launch();
//  }
//  
//  @When("I enter valid credentials") 
//  public void I_enter_valid_credentials() {
//	  s.enterCredentials();
//  }
//  
//  @And("I click the login button") 
//  public void I_click_the_login_button() {
//	  s.clickLogin();
//  }
//  
//}
