package com.booksWagon.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.booksWagon.pages.BasePage;
import com.booksWagon.pages.SearchModule;
import com.booksWagon.utils.ExcelUtils;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BasicSearchSteps {
	
//		WebDriver driver = BasePage.getDriver(); // assuming you have a static getDriver() method
		
	
		WebDriver driver;
	    SearchModule searchModule;
	   
	    String searchWord;
	    String caseType;
	    String searchResult;
	    Boolean val;
	    String s;
	    List<String> data = new ArrayList<String>();
		String path = "C:\\Users\\tavva.teja\\Downloads\\BooksWagon1\\BooksWagon1\\src\\test\\resources\\testingData\\TestData.xlsx";
	    int row = 0;
	    
	    @Before
	    public void setup() throws IOException {
	        System.out.println("[Before Hook] Initializing WebDriver...");
	        driver = new ChromeDriver();
	        searchModule = new SearchModule(driver);
	        ExcelUtils.setExcelFile(path, "Data");

	        row = ExcelUtils.getRowCount(path, "Data1");
	    }
//	    1)
//	    @When("I enter keyword in search bar with case type for validation")
//	    public void I_enter_keyword_in_search_bar_with_case_type_for_validation() throws IOException {
//	        System.out.println("Total Rows: " + row);
//	        
//	        for (int i = 1; i <= row; i++) {
//	            String searchWord = ExcelUtils.getCellData(path, "Data1", i, 0);
//
//	            // Logging case type
//	            if (searchWord == null || searchWord.trim().isEmpty()) {
//	                System.out.println("Running search for BLANK value...");
//	            } else if (searchWord.equalsIgnoreCase("Java")) {
//	                System.out.println("Running VALID search for: " + searchWord);
//	            } else {
//	                System.out.println("Running INVALID search for: " + searchWord);
//	            }
//
//	            // Execute search for ALL cases (including blank values)
//	            searchModule.enter_search_term(searchWord); // Ensures empty search is entered
//	            searchModule.click_search_button();
//	            searchModule.validateCase(searchWord, data);
//
//	            // Store validation results
//	            data.add(String.valueOf(val));
//	            driver.navigate().to("https://www.bookswagon.com");
//	            System.out.println(data.toString());
//
//	        }
//	    }
	    
	    @When("I enter keyword in search bar with case type for validation")
	    public void I_enter_keyword_in_search_bar_with_case_type_for_validation() throws IOException {
	        System.out.println("Total Rows: " + row);

	        for (int i = 1; i <= row; i++) {
	            String searchWord = ExcelUtils.getCellData(path, "Data1", i, 0);
	            String caseWord = ExcelUtils.getCellData(path, "Data1", i, 3);

	            // Logging case type
	            if (searchWord == null || searchWord.trim().isEmpty()) {
	                System.out.println("Running search for BLANK value...");
	            } else if (caseWord.equalsIgnoreCase("Valid")) {
	                System.out.println("Running VALID search for: " + searchWord);
	            } else {
	                System.out.println("Running INVALID search for: " + searchWord);
	            }

	            // Execute search for all cases
	            searchModule.enter_search_term(searchWord);
	            searchModule.click_search_button();
	            
	            // Validate search results and store in `data` list
	            searchModule.validateCase(searchWord, data);
//	            data.add(String.valueOf(val));  // Ensure it's stored properly

	            // Navigate back for the next test case
	            driver.navigate().to("https://www.bookswagon.com");

	            // Debugging stored data
	            System.out.println("Data List After " + (searchWord.isEmpty() ? "[BLANK]" : searchWord) + " Search: " + data.toString());
	        }
	    }




//	    @After
//	    public void tearDown() throws IOException {
//	        ExcelUtils.closeExcel(); // Close after all tests
////	        driver.quit();
//	    }
	    
	    @Then ("I store the each test case after validating test case")
	    public void I_store_the_each_test_case_after_validating_test_case() throws IOException {
	    	searchModule.populateExcelData(data, "Data1");
	    }
}


